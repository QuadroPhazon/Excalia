package fr.evenkia.launcher;

import java.io.File;

import fr.theshark34.openauth.AuthenticationException;
import fr.theshark34.openlauncherlib.launcher.AuthInfos;
import fr.theshark34.openlauncherlib.launcher.GameInfos;
import fr.theshark34.openlauncherlib.launcher.GameTweak;
import fr.theshark34.openlauncherlib.launcher.GameType;
import fr.theshark34.openlauncherlib.launcher.GameVersion;
import fr.theshark34.supdate.SUpdate;

public class Launcher {

	public static final GameVersion SC_VERSION = new GameVersion("1.7.10", GameType.V1_7_10);
	public static final GameInfos SC_INFOS = new GameInfos("Evenkia", SC_VERSION, true, new GameTweak[] {GameTweak.FORGE});
	public static final File SC_DIR = SC_INFOS.getGameDir();
	
	private static AuthInfos authInfos;
	
	public static void auth(String username) throws AuthenticationException {
		authInfos = new AuthInfos(username, "sry", "nope");
	}
	
	public static void update() throws Exception {
		SUpdate su = new SUpdate("http://ventuss.livehost.fr/", SC_DIR);
		su.start();
	}
}	