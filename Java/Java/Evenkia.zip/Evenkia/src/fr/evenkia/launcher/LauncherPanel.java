package fr.evenkia.launcher;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import fr.theshark34.openauth.AuthenticationException;
import fr.theshark34.openlauncherlib.launcher.util.UsernameSaver;
import fr.theshark34.swinger.Swinger;
import fr.theshark34.swinger.event.SwingerEvent;
import fr.theshark34.swinger.event.SwingerEventListener;
import fr.theshark34.swinger.textured.STexturedButton;
import fr.theshark34.swinger.textured.STexturedProgressBar;

@SuppressWarnings("serial")
public class LauncherPanel extends JPanel implements SwingerEventListener {
	
	private Image background = Swinger.getResource("Fond2.png");
	
	private UsernameSaver saver = new UsernameSaver(Launcher.SC_INFOS);
	
	private JTextField usernameField = new JTextField(saver.getUsername(""));
	
	private STexturedButton playButton = new STexturedButton(Swinger.getResource("play.png"));
	private STexturedButton quitButton = new STexturedButton(Swinger.getResource("quit.png"));
	private STexturedButton hideButton = new STexturedButton(Swinger.getResource("hide.png"));
	
	STexturedProgressBar progressBar = new STexturedProgressBar(Swinger.getResource("100Bar.png"), Swinger.getResource("0Bar.png"));
	private JLabel infoLabel = new JLabel("By Ventuss & Laynom", SwingConstants.CENTER);

	
	public LauncherPanel() {
		this.setLayout(null);
		
		usernameField.setFont(usernameField.getFont().deriveFont(20F));
		usernameField.setOpaque(false);
		usernameField.setBorder(null);
		usernameField.setBounds(148, 256, 266, 39);
		this.add(usernameField);
		
		playButton.setBounds(530, 258);
		playButton.addEventListener(this);
		this.add(playButton);
		
		quitButton.setBounds(818, 0);
		quitButton.addEventListener(this);
		this.add(quitButton);
		
		hideButton.setBounds(776, 0);
		hideButton.addEventListener(this);
		this.add(hideButton);
		
		progressBar.setBounds(176, 310, 500, 12);
		this.add(progressBar);
		
		infoLabel.setForeground(Color.WHITE);
		infoLabel.setFont(usernameField.getFont());
		infoLabel.setBounds(176, 330, 500, 19);
		this.add(infoLabel);
	}
	


	@Override
	public void onEvent(SwingerEvent e) {
		if(e.getSource() == playButton) {
			setFieldEnabled(false);
			
			if(usernameField.getText().replaceAll(" ", " ").length() == 0) {
				JOptionPane.showMessageDialog(this, "Erreur, pseudo incorrect");
				setFieldEnabled(true);
				return;
			}
			
			Thread t = new Thread() {
				@Override
				public void run() {
					try {
						Launcher.auth(usernameField.getText());
					} catch (AuthenticationException e) {
						JOptionPane.showMessageDialog(LauncherPanel.this, "Erreur : " + e.getErrorModel().getErrorMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
						setFieldEnabled(true);
						return;
						}
					System.out.println("Ca marche");
				}
			};
			t.start();
		}	else if(e.getSource() == quitButton)
				System.exit(0);
		else if(e.getSource() == hideButton)
			LauncherFrame.getInstance().setState(JFrame.ICONIFIED);
	
	
	}
	
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponents(g);
		
		g.drawImage(background, 0, 0, this.getWidth(), this.getHeight(), this);
	}
	
	private void setFieldEnabled(boolean enabled) {
		usernameField.setEnabled(enabled);
		playButton.setEnabled(enabled);
	}

	public STexturedProgressBar getProgressBar() {
		return progressBar;
	}
	
	public void setInfoText(String text) {
		infoLabel.setText(text);
	}
}
